<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-pricing-list/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-pricing-list/advanced-pricing-list.php';